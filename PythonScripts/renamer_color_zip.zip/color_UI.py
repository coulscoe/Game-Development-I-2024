﻿import maya.cmds as cmds
import color_changer
class colorUI():
    def __init__(self):
        self.mWindow = "ccWindow"
    def create(self):
        self.delete()

        self.mWindow = cmds.window(self.mWindow, title='Color UI',
                              widthHeight=(350, 10),
                              resizeToFitChildren=True)
        mColumn = cmds.columnLayout(parent=self.mWindow, adjustableColumn=True)
        cmds.text(parent=mColumn, label='Enter number to change color of control', align='center')
        self.ccIntField= cmds.intSlider(parent=mColumn, maxValue=31, minValue=0)
        cmds.button(parent=mColumn, label='Change Color', command=lambda *args: self.color_changerCmd())
        cmds.showWindow(self.mWindow)
    def delete(self):
        if (cmds.window(self.mWindow, exists=True)):
            cmds.deleteUI(self.mWindow)
    def color_changerCmd(self):
        color = cmds.intSlider(self.ccIntField, q=True, v=True)
        cmd = color_changer.color_changer(color)