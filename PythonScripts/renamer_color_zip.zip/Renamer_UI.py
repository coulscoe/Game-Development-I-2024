﻿import maya.cmds as cmds
import Renamer

class renamerUI():
    def __init__(self):
        self.mWindow = "rnWindow"
    def create(self):
        self.delete()

        self.mWindow = cmds.window(self.mWindow, title='Renamer UI',
                                   widthHeight=(350, 10),
                                   resizeToFitChildren=True)
        mColumn = cmds.columnLayout(parent=self.mWindow, adjustableColumn=True)
        cmds.text(parent=mColumn, label='Enter name to change obj name. Use format name_###(how much number padding needed)_objType '
                                        'such as "R_Leg_####_Jnt"', align='center')
        self.text=cmds.textField(parent=mColumn)
        cmds.button(parent=mColumn, label='Rename', command=lambda *args: self.sequential_renamerCmd())
        cmds.showWindow(self.mWindow)
    def delete(self):
        if (cmds.window(self.mWindow, exists=True)):
            cmds.deleteUI(self.mWindow)

    def sequential_renamerCmd(self):
        name=cmds.textField(self.text, query=True, text=True)
        nameCmd= Renamer.sequential_renamer(name)